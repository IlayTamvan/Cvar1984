import os, sys
###############
# Dede : Hair #
# Fors : Repo #
###############
try:
 print('')
 print('[0m=====================================================[0;91m')
 os.system('figlet AUTOMATIC')
 print('[0m=====================================================')
 print('[^_*] Penyusun Ilay Tamvan [[0;93mIlay[0m]') 
 print('[^_^] Repo Github Milik Si [[0;93mCvar1984[0m]')
 print('''[0m====================================================
 [0;92m[[0m1[0;92m] [0mInstall[0;93m -Pirates-of-the-Caribbean-Theme-Song
 [0;92m[[0m2[0;92m] [0mInstall[0;93m Autoreaction
 [0;92m[[0m3[0;92m] [0mInstall[0;93m b374k
 [0;92m[[0m4[0;92m] [0mInstall[0;93m bacod
 [0;92m[[0m5[0;92m] [0mInstall[0;93m cache
 [0;92m[[0m6[0;92m] [0mInstall[0;93m checker
 [0;92m[[0m7[0;92m] [0mInstall[0;93m crusader
 [0;92m[[0m8[0;92m] [0mInstall[0;93m Cvar1984.github.io
 [0;92m[[0m9[0;92m] [0mInstall[0;93m Deface
 [0;92m[[0m10[0;92m] [0mInstall[0;93m Easymap
 [0;92m[[0m11[0;92m] [0mInstall[0;93m Ecode
 [0;92m[[0m12[0;92m] [0mInstall[0;93m Facebook-Video-Downloader
 [0;92m[[0m13[0;92m] [0mInstall[0;93m Hac
 [0;92m[[0m14[0;92m] [0mInstall[0;93m InstaPoster
 [0;92m[[0m15[0;92m] [0mInstall[0;93m IRC_botnet
 [0;92m[[0m16[0;92m] [0mInstall[0;93m lain
 [0;92m[[0m17[0;92m] [0mInstall[0;93m LaZagne
 [0;92m[[0m18[0;92m] [0mInstall[0;93m LiteOTP
 [0;92m[[0m19[0;92m] [0mInstall[0;93m MusicalArray
 [0;92m[[0m20[0;92m] [0mInstall[0;93m OOPPHPPDO
 [0;92m[[0m21[0;92m] [0mInstall[0;93m Pastebin
 [0;92m[[0m22[0;92m] [0mInstall[0;93m pemulungBTC
 [0;92m[[0m23[0;92m] [0mInstall[0;93m php-backend-generator
 [0;92m[[0m24[0;92m] [0mInstall[0;93m php-stegano-lsb
 [0;92m[[0m25[0;92m] [0mInstall[0;93m reserved-subdomains
 [0;92m[[0m26[0;92m] [0mInstall[0;93m SGen
 [0;92m[[0m27[0;92m] [0mInstall[0;93m Sipher-PHP-Ransomware
 [0;92m[[0m28[0;92m] [0mInstall[0;93m Spammer-Grab
 [0;92m[[0m29[0;92m] [0mInstall[0;93m SpiderBot
 [0;92m[[0m30[0;92m] [0mInstall[0;93m Spyder''')
 f=["https://github.com/Cvar1984/-Pirates-of-the-Caribbean-Theme-Song.git", "https://github.com/Cvar1984/Autoreaction.git", "https://github.com/Cvar1984/b374k.git", "https://github.com/Cvar1984/bacod.git", "https://github.com/Cvar1984/cache.git", "https://github.com/Cvar1984/checker.git", "https://github.com/Cvar1984/crusader.git", "https://github.com/Cvar1984/Cvar1984.github.io.git", "https://github.com/Cvar1984/Deface.git", "https://github.com/Cvar1984/Easymap.git", "https://github.com/Cvar1984/Ecode.git", "https://github.com/Cvar1984/Facebook-Video-Downloader.git", "https://github.com/Cvar1984/Hac.git", "https://github.com/Cvar1984/InstaPoster.git", "https://github.com/Cvar1984/IRC_botnet.git", "https://github.com/Cvar1984/lain.git", "https://github.com/Cvar1984/LaZagne.git", "https://github.com/Cvar1984/LiteOTP.git", "https://github.com/Cvar1984/MusicalArray.git", "https://github.com/Cvar1984/OOPPHPPDO.git", "https://github.com/Cvar1984/Pastebin.git", "https://github.com/Cvar1984/pemulungBTC.git", "https://github.com/Cvar1984/php-backend-generator.git", "https://github.com/Cvar1984/php-stegano-lsb.git", "https://github.com/Cvar1984/reserved-subdomains.git", "https://github.com/Cvar1984/SGen.git", "https://github.com/Cvar1984/Sipher-PHP-Ransomware.git", "https://github.com/Cvar1984/Spammer-Grab.git", "https://github.com/Cvar1984/SpiderBot.git", "https://github.com/Cvar1984/Spyder.git"]
 print('[0m=====================================================')
 Plh=input('[0;93m[><][0m Install Nomer : ')
 print('=====================================================')
 Y=f[Plh-1]
 if f !=[]:
   try:
     os.system('git clone '+Y)
     print('=====================================================')
     print('[><] Selesai Install (Cek Folder)')
     print('=====================================================')
     os.system('ls')
     print('=====================================================')
   except(ImportError):
     sys.exit()
 else:
   sys.exit()
except(IndexError):
  print('=====================================================')
  print('Nomer > [0;91m['+str(Plh-1)+'[0;91m] [0;93mTidak Ada [0;92m Blaa[0;91mBlaa[0mBlaa..[92m([0;96mCek Ulang[0;96)[0m)')
  print('=====================================================')
  sys.exit()